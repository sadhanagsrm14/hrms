<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'AuthController@index')->middleware('guest');
Route::get('login', 'AuthController@index')->middleware('guest');
Route::post('/login','AuthController@login')->name('login');
Route::get('/logout','AuthController@logout');
Route::get('/forget-password','AuthController@getForgetPassword');
Route::post('/forget-password','AuthController@postForgetPassword');
Route::get('/verify_reset_token/{token}','AuthController@verify_reset_token');
Route::post('/reset-password','AuthController@post_reset_password');
Route::get('/credit-leave','AjaxController@creditLeave');
Route::group(['middleware' => ['auth']], function () {
	Route::get('/profile','ProfileController@profile');
	Route::post('/postChangePassword','ProfileController@postChangePassword');
	Route::post('/profile/update/profile-pic','ProfileController@updateProfilePic');
	Route::get('/readNotification/{id}','NotificationController@notification');
	Route::get('/getSystem/{id}','AjaxController@getSystem');
	Route::get('/getAsset/{id}','AjaxController@getAsset');
	Route::get('/getUser/{id}','AjaxController@getUser');
	Route::get('/getNewSystemId','AjaxController@getNewSystemId');
	Route::get('/getMasterSystemById/{id}','AjaxController@getMasterSystemById');
	Route::get('/getEod/{id}','AjaxController@getEod');
	Route::get('/getSubEod/{id}','AjaxController@getSubEod');
	Route::get('/getProject/{id}','AjaxController@getProject');

	Route::get('/resignations','ResignController@resignations');
	Route::get('/resign','ResignController@getApplyResign');
	Route::post('/resign','ResignController@postApplyResign');
	Route::get('/resignation/{id}','ResignController@previewResign');
});

Route::group(['middleware' => ['auth','admin']], function () {

	Route::get('/admin/dashboard','AdminController@dashboard');
	Route::get('/admin/teams','AdminController@teams');
	Route::get('/admin/assign-team-members','AdminController@getAddAssignTeam');
	Route::post('/admin/assign-team-members','AdminController@postAddAssignTeam');
	Route::get('/admin/team-members/{team_leader_id}','AdminController@teamMembers');
	Route::get('/admin/remove/team-member/{team_member_id}','AdminController@removeTeamMember');
	Route::get('/admin/resignations', 'AdminController@resignations');
	/*=======================Admin Dashboard Starts==========================*/

	Route::get('/admin/dashboard','AdminController@dashboard');

	/*=======================Employee routes starts==========================*/
	Route::get('/admin/employees', 'EmployeeController@employees');
	Route::get('/admin/add-employee', 'EmployeeController@getAddEmployee');
	Route::post('/admin/add-employee', 'EmployeeController@postAddEmployee');
	Route::get('/admin/employee/profile/{id}', 'EmployeeController@getEmployeeProfile');
	Route::get('/admin/employee/{id}', 'EmployeeController@getEditEmployee');
	Route::post('/admin/employee/update', 'EmployeeController@postEditEmployee');
	Route::get('/admin/employee/delete/{id}', 'EmployeeController@deleteEmployee');
	Route::get('/admin/export/employee-sheet', 'EmployeeController@exportEmployees');
	Route::post('/admin/import/employee-sheet', 'EmployeeController@importEmployees');
	/*=======================Employee routes ends============================*/

	/*==========================Project routes starts===========================*/
	Route::get('/admin/projects', 'ProjectController@projects');
	Route::get('/admin/add-project', 'ProjectController@getAddProject');
	Route::post('/admin/add-project', 'ProjectController@postAddProject');
	Route::get('/admin/project/{id}', 'ProjectController@getEditProject');
	Route::post('/admin/project/update', 'ProjectController@postEditProject');
	Route::get('/admin/project/delete/{id}', 'ProjectController@deleteProject');
	/*==========================Project routes ends==============================*/

	/*==========================Employee Project routes starts===========================*/
	Route::get('/admin/employee-projects', 'EmployeeProjectController@employee_projects');
	Route::get('/admin/assign-project', 'EmployeeProjectController@getAssignProject');
	Route::post('/admin/assign-project', 'EmployeeProjectController@postAssignProject');
	Route::get('/admin/employee-project/{id}', 'EmployeeProjectController@getEditEmployeeProject');
	Route::post('/admin/employee-project/update', 'EmployeeProjectController@postEditEmployeeProject');
	Route::get('/admin/employee-project/delete/{id}', 'EmployeeProjectController@deleteEmployeeProject');
	/*==========================Employee Project routes ends==============================*/

	/*==========================Leave routes starts===========================*/
	Route::get('/admin/leave-types', 'AdminLeaveController@leave_types');
	Route::get('/admin/add-leave-type', 'AdminLeaveController@getAddLeaveType');
	Route::post('/admin/add-leave-type', 'AdminLeaveController@postAddLeaveType');
	Route::get('/admin/leave-type/{id}', 'AdminLeaveController@getEditLeaveType');
	Route::post('/admin/leave-type/update', 'AdminLeaveController@postEditLeaveType');
	Route::get('/admin/leave-listing', 'AdminLeaveController@leave_listing');
	Route::get('/admin/leave/approve/{id}', 'AdminLeaveController@approveLeave');
	Route::get('/admin/leave/discard/{id}', 'AdminLeaveController@discardLeave');
	Route::get('/admin/leave/delete/{id}', 'AdminLeaveController@deleteLeave');
	/*==========================Leave routes ends==============================*/

	/*==========================Asset routes starts===========================*/
	Route::get('/admin/systems', 'AssetController@systems');
	Route::get('/admin/add-system', 'AssetController@getAddSystem');
	Route::post('/admin/add-system', 'AssetController@postAddSystem');
	Route::get('/admin/system/{id}', 'AssetController@getEditSystem');
	Route::post('/admin/system/update', 'AssetController@postEditSystem');
	Route::get('/admin/assets', 'AssetController@assets');
	Route::get('/admin/add-asset', 'AssetController@getAddAsset');
	Route::post('/admin/add-asset', 'AssetController@postAddAsset');
	Route::get('/admin/asset/{id}', 'AssetController@getEditAsset');
	Route::post('/admin/asset/post', 'AssetController@postEditAsset');
	Route::post('/admin/asset/update', 'AssetController@postEditAsset');
	Route::get('/admin/asset/delete/{id}', 'AssetController@deleteAsset');
	Route::get('admin/asset_master/{type_id}', 'AjaxController@getMasterAssetByType');
	Route::get('admin/assetsByAssetType/{type_id}', 'AjaxController@getAssetByAssetType');
	Route::get('admin/free_assets/{type_id}/{asset_assoc_id}', 'AjaxController@freeAssets');
	Route::get('admin/assignAsset/{system_id}/{asset_id}', 'AjaxController@assignAsset');
	Route::get('admin/assetRelease/{id}', 'AjaxController@releaseAsset');
	Route::get('admin/release-system-asset/{system_id}/{id}', 'AssetController@releaseSystemAsset');
	Route::get('/admin/export/asset-sheet', 'AssetController@exportAssetExcel');
	Route::get('/admin/export/system-sheet', 'ITExecutiveController@exportSystemExcel');
	Route::post('/admin/import/asset-sheet', 'AssetController@importAssetExcel');
	/*==========================Asset routes ends==============================*/

	/*==========================Holidays routes starts===========================*/
	Route::get('/admin/holiday-calender', 'HolidayController@holidayCalender');
	Route::get('/admin/holidays', 'HolidayController@holidays');
	Route::get('/admin/add-holiday', 'HolidayController@getAddHoliday');
	Route::post('/admin/add-holiday', 'HolidayController@postAddHoliday');
	Route::get('/admin/holiday/{id}', 'HolidayController@getEditHoliday');
	Route::post('/admin/holiday/update', 'HolidayController@postEditHoliday');
	Route::get('/admin/holiday/delete/{id}', 'HolidayController@deleteHoliday');
	Route::get('/admin/export/holiday-sheet', 'HolidayController@exportHolidayExcel');
	Route::post('/admin/import/holiday-sheet', 'HolidayController@importHolidayExcel');
	/*==========================Holidays routes end==============================*/

	/*==========================EOD routes starts===========================*/
	Route::get('/admin/eods', 'EODController@eod_list');
	Route::get('/admin/eod/{eod_id}', 'EODController@getEODToAdmin');
	Route::get('/admin/eod/delete/{eod_id}', 'EODController@deleteEOD');
	/*==========================EOD routes ends==============================*/

	/*==========================   Attendance Start   ==============================*/
	Route::get('/admin/attendance', 'AttendanceController@attendance');
	Route::post('admin/submitAttendance', 'AttendanceController@submitAttendance');
	Route::post('admin/getcurentAttendance', 'AttendanceController@getcurentAttendance');
	Route::get('/admin/export/attendance-sheet', 'AttendanceController@exportAttendanceExcel');
	Route::post('/admin/import/attendance-sheet', 'AttendanceController@importAttendanceExcel');

	/*==========================   Attendance End   ==============================*/

	/*==========================Requests routes starts===========================*/
	Route::get('admin/request/profile-update', 'AdminRequestController@profileUpdateRequest');
	Route::get('admin/request/profile/{id}', 'AdminRequestController@getProfileUpdateRequest');
	Route::get('admin/request/profile/approve/{id}', 'AdminRequestController@approveProfileUpdateRequest');
	Route::get('admin/request/profile/discard/{id}', 'AdminRequestController@discardProfileUpdateRequest');
	/*==========================Requests routes ends==============================*/
	

	/*=========================Admin Dashboard Ends============================*/
});



/*=======================Employee Dashboard starts========================*/
Route::group(['middleware' => ['auth','employee']], function () {
	Route::get('/employee/dashboard','EmployeeController@dashboard');
	Route::get('/employee/holiday-calender', 'EmployeeController@holidayCalender');
	Route::get('/employee/assigned-projects', 'EmployeeController@getAssisnedProject');
	/*==========================Leave routes starts===========================*/
	Route::get('/employee/apply-leave', 'EmployeeLeaveController@getAddLeave');
	Route::post('/employee/apply-leave', 'EmployeeLeaveController@postAddLeave');
	Route::get('/employee/my-leaves', 'EmployeeLeaveController@myLeaves');
	/*==========================Leave routes ends==============================*/

	/*==========================EOD routes starts===========================*/
	Route::get('/employee/see-eod', 'EODController@getSeeTeamEOD');
	Route::get('/employee/send-eod', 'EODController@getSendEOD');
	Route::post('/employee/send-eod', 'EODController@postSendEOD');
	Route::get('/employee/sent-eods', 'EODController@sent_eod');
	Route::get('/employee/eod/{eod_id}', 'EODController@getEOD');
	/*==========================EOD routes ends==============================*/

	/*==========================Profile Update request routes starts===========================*/
	Route::get('/employee/profile', 'EmployeeController@getProfile');
	Route::get('/employee/profile/edit', 'EmployeeController@getProfileEdit');
	Route::post('/employee/profile/edit', 'EmployeeController@postProfileEdit');
	Route::post('/employee/addAttendance', 'EmployeeController@addAttendance');
	/*==========================Profile Update request routes ends==============================*/


	/*==========================Resignation routes starts===========================*/
	Route::get('/employee/resignation/retract/{id}', 'ResignController@retractResign');
	Route::get('/employee/resignation/submit/{id}', 'ResignController@submitResign');
	/*==========================Resignation routes ends==============================*/

});
/*=======================Employee Dashboard Ends==========================*/


/*========================Hr Manager Dashboard starts========================*/
Route::group(['middleware' => ['auth','hrManager']], function () {
	Route::get('/hrManager/dashboard','HrManagerController@dashboard');
	Route::get('/hrManager/teams','HrManagerController@teams');
	Route::get('/hrManager/assign-team-members','HrManagerController@getAddAssignTeam');
	Route::post('/hrManager/assign-team-members','HrManagerController@postAddAssignTeam');
	Route::get('/hrManager/team-members/{team_leader_id}','HrManagerController@teamMembers');
	Route::get('/hrManager/remove/team-member/{team_member_id}','HrManagerController@removeTeamMember');

	/*=======================Employee routes starts==========================*/
	Route::get('/hrManager/employees', 'HrManagerController@employees');
	Route::get('/hrManager/add-employee', 'HrManagerController@getAddEmployee');
	Route::post('/hrManager/add-employee', 'HrManagerController@postAddEmployee');
	Route::get('/hrManager/employee/profile/{id}', 'HrManagerController@getEmployeeProfile');
	Route::get('/hrManager/employee/{id}', 'HrManagerController@getEditEmployee');
	Route::post('/hrManager/employee/update', 'HrManagerController@postEditEmployee');
	Route::get('/hrManager/employee/delete/{id}', 'HrManagerController@deleteEmployee');
	Route::get('/hrManager/export/employee-sheet', 'HrManagerController@exportEmployees');
	Route::post('/hrManager/import/employee-sheet', 'HrManagerController@importEmployees');
	/*=======================Employee routes ends============================*/

	
	/*==========================Leave routes starts===========================*/
	Route::get('/hrManager/leave-types', 'HrManagerController@leave_types');
	Route::get('/hrManager/add-leave-type', 'HrManagerController@getAddLeaveType');
	Route::post('/hrManager/add-leave-type', 'HrManagerController@postAddLeaveType');
	Route::get('/hrManager/leave-type/{id}', 'HrManagerController@getEditLeaveType');
	Route::post('/hrManager/leave-type/update', 'HrManagerController@postEditLeaveType');
	Route::get('/hrManager/leave-listing', 'HrManagerController@leave_listing');
	Route::get('/hrManager/leave/approve/{id}', 'HrManagerController@approveLeave');
	Route::get('/hrManager/leave/discard/{id}', 'HrManagerController@discardLeave');
	Route::get('/hrManager/leave/delete/{id}', 'HrManagerController@deleteLeave');

	Route::get('/hrManager/apply-leave', 'HrManagerController@getAddLeave');
	Route::post('/hrManager/apply-leave', 'HrManagerController@postAddLeave');
	Route::get('/hrManager/my-leaves', 'HrManagerController@myLeaves');
	
	/*==========================Leave routes ends==============================*/

	/*==========================Holidays routes starts===========================*/
	Route::get('/hrManager/holiday-calender', 'HrManagerController@holidayCalender');
	Route::get('/hrManager/holidays', 'HrManagerController@holidays');
	Route::get('/hrManager/add-holiday', 'HrManagerController@getAddHoliday');
	Route::post('/hrManager/add-holiday', 'HrManagerController@postAddHoliday');
	Route::get('/hrManager/holiday/{id}', 'HrManagerController@getEditHoliday');
	Route::post('/hrManager/holiday/update', 'HrManagerController@postEditHoliday');
	Route::get('/hrManager/holiday/delete/{id}', 'HrManagerController@deleteHoliday');
	Route::get('/hrManager/export/holiday-sheet', 'HrManagerController@exportHolidayExcel');
	Route::post('/hrManager/import/holiday-sheet', 'HrManagerController@importHolidayExcel');
	/*==========================Holidays routes end==============================*/

	/*==========================   Attendance Start   ==============================*/
	Route::get('/hrManager/attendance', 'HrManagerController@attendance');
	Route::post('hrManager/submitAttendance', 'HrManagerController@submitAttendance');
	Route::post('hrManager/getcurentAttendance', 'HrManagerController@getcurentAttendance');
	Route::get('/hrManager/export/attendance-sheet', 'HrManagerController@exportAttendanceExcel');
	Route::post('/hrManager/import/attendance-sheet', 'HrManagerController@importAttendanceExcel');

	/*==========================   Attendance End   ==============================*/
	
	/*==========================Requests routes starts===========================*/
	Route::get('hrManager/request/profile-update', 'HrManagerController@profileUpdateRequest');
	Route::get('hrManager/request/profile/{id}', 'HrManagerController@getProfileUpdateRequest');
	Route::get('hrManager/request/profile/approve/{id}', 'HrManagerController@approveProfileUpdateRequest');
	Route::get('hrManager/request/profile/discard/{id}', 'HrManagerController@discardProfileUpdateRequest');

	Route::post('/hrManager/addAttendance', 'HrManagerController@addAttendance');
	Route::get('/hrManager/leave-details', 'HrManagerController@leave_details');
	/*==========================Requests routes ends==============================*/

	/*==========================EOD routes starts===========================*/
	Route::get('/hrManager/send-eod', 'HrManagerController@getSendEOD');
	Route::post('/hrManager/send-eod', 'HrManagerController@postSendEOD');
	Route::get('/hrManager/sent-eods', 'HrManagerController@sent_eod');
	/*==========================EOD routes ends==============================*/

	/*==========================Profile Update request routes starts===========================*/
	Route::get('/hrManager/profile/edit', 'HrManagerController@getProfileEdit');
	Route::post('/hrManager/profile/edit', 'HrManagerController@postProfileEdit');
	/*==========================Profile Update request routes ends==============================*/

	/*==========================Resignation routes starts===========================*/
	Route::get('/hrManager/resignations', 'HrManagerController@resignations');
	Route::get('/hrManager/resignation/retract/{id}', 'ResignController@retractResign');
	Route::get('/hrManager/resignation/submit/{id}', 'ResignController@submitResign');
	/*==========================Resignation routes ends==============================*/

});
/*=======================Hr Manager Dashboard Ends==========================*/


/*========================IT Executive Dashboard starts========================*/
Route::group(['middleware' => ['auth','itExecutive']], function () {
	Route::get('/itExecutive/dashboard','ITExecutiveController@dashboard');
	Route::get('/itExecutive/holiday-calender', 'ITExecutiveController@holidayCalender');
	Route::get('/itExecutive/profile', 'ITExecutiveController@getProfile');
	Route::get('/itExecutive/profile/edit', 'ITExecutiveController@getProfileEdit');
	Route::post('/itExecutive/profile/edit', 'ITExecutiveController@postProfileEdit');
	Route::post('/itExecutive/addAttendance', 'ITExecutiveController@addAttendance');

	/*==========================Asset routes starts===========================*/
	Route::get('/itExecutive/systems', 'ITExecutiveController@systems');
	Route::get('/itExecutive/add-system', 'ITExecutiveController@getAddSystem');
	Route::post('/itExecutive/add-system', 'ITExecutiveController@postAddSystem');
	Route::get('/itExecutive/system/{id}', 'ITExecutiveController@getEditSystem');
	Route::post('/itExecutive/system/update', 'ITExecutiveController@postEditSystem');
	Route::get('/itExecutive/assets', 'ITExecutiveController@assets');
	Route::get('/itExecutive/add-asset', 'ITExecutiveController@getAddAsset');
	Route::post('/itExecutive/add-asset', 'ITExecutiveController@postAddAsset');
	Route::get('/itExecutive/asset/{id}', 'ITExecutiveController@getEditAsset');
	Route::post('/itExecutive/asset/post', 'ITExecutiveController@postEditAsset');
	Route::post('/itExecutive/asset/update', 'ITExecutiveController@postEditAsset');
	Route::get('/itExecutive/asset/delete/{id}', 'ITExecutiveController@deleteAsset');
	Route::get('itExecutive/asset_master/{type_id}', 'AjaxController@getMasterAssetByType');
	Route::get('itExecutive/assetsByAssetType/{type_id}', 'AjaxController@getAssetByAssetType');
	Route::get('itExecutive/free_assets/{type_id}/{asset_assoc_id}', 'AjaxController@freeAssets');
	Route::get('itExecutive/assignAsset/{system_id}/{asset_id}', 'AjaxController@assignAsset');
	Route::get('itExecutive/assetRelease/{id}', 'AjaxController@releaseAsset');
	Route::get('itExecutive/release-system-asset/{system_id}/{id}', 'ITExecutiveController@releaseSystemAsset');
	Route::get('/itExecutive/export/asset-sheet', 'ITExecutiveController@exportAssetExcel');
	Route::get('/itExecutive/export/system-sheet', 'ITExecutiveController@exportSystemExcel');
	Route::post('/itExecutive/import/asset-sheet', 'ITExecutiveController@importAssetExcel');
	/*==========================Asset routes ends==============================*/

	/*==========================Leave routes starts===========================*/
	Route::get('/itExecutive/apply-leave', 'ITExecutiveController@getAddLeave');
	Route::post('/itExecutive/apply-leave', 'ITExecutiveController@postAddLeave');
	Route::get('/itExecutive/my-leaves', 'ITExecutiveController@myLeaves');
	/*==========================Leave routes ends==============================*/
	
	/*==========================Resignation routes starts===========================*/
	Route::get('/itExecutive/resignation/retract/{id}', 'ResignController@retractResign');
	Route::get('/itExecutive/resignation/submit/{id}', 'ResignController@submitResign');
	/*==========================Resignation routes ends==============================*/

});

//Route::group(['middleware' => 'auth'], function () {

Route::get('/teamLead/dashboard', 'TeamLeadController@getDashboard');

//});
/*=======================IT Executive Dashboard Ends==========================*/
