      <div class="page-sidebar sidebar">
      	<div class="page-sidebar-inner slimscroll">
      		<div class="sidebar-header">
      			<div class="sidebar-profile">
              <!-- <a href="javascript:void(0);" id="profile-menu-link"> -->
                <a href="javascript:void(0);">
                 <div class="sidebar-profile-image">
                  <img src="{{\Auth::user()->cb_profile->employee_pic}}" class="img-circle img-responsive" alt="">
                </div>
                <div class="sidebar-profile-details">
                  <span>{{\Auth::user()->first_name}}<br><small>{{\Auth::user()->cb_profile->designation}}</small></span>
                </div>
              </a>
            </div>
          </div>

          <ul class="menu accordion-menu">
           <li class="{{setActive('employee/dashboard')}}"><a href="{{URL('/employee/dashboard')}}" class="waves-effect waves-button"><span class="menu-icon glyphicon glyphicon-home"></span><p>Dashboard</p></a></li>

           <li class="droplink {{setActive('employee/apply-leave')}}  {{setActive('employee/my-leaves')}}"><a href="#" class="waves-effect waves-button"><span class="menu-icon glyphicon glyphicon-briefcase"></span><p>Leaves</p><span class="arrow"></span></a>
            <ul class="sub-menu">
              <li><a href="{{URL('/employee/apply-leave')}}">Apply Leave</a></li>
              <li><a href="{{URL('/employee/my-leaves')}}">My Leaves</a></li>
            </ul>
          </li>

          <li class="droplink {{setActive('employee/send-eod')}} {{setActive('employee/sent-eods')}}"><a href="#" class="waves-effect waves-button"><span class="menu-icon glyphicon glyphicon-briefcase"></span><p>EODs</p><span class="arrow"></span></a>
            <ul class="sub-menu">

            	@if(Auth::user()->role == 4)
              <li><a href="{{URL('/employee/see-eod')}}">Team Member's EOD</a></li>
              @endif

              <li><a href="{{URL('/employee/sent-eods')}}">My Sent EODs</a></li>
              <li><a href="{{URL('/employee/send-eod')}}">Send</a></li>
            </ul>
          </li>

          <li class="droplink {{setActive('resign')}}">
            <a href="#" class="waves-effect waves-button"><span class="menu-icon glyphicon glyphicon-home"></span><p>Resignation</p><span class="arrow"></span></a>
            <ul class="sub-menu">
              @if(is_null(\Auth::user()->resignation))
              <li><a href="{{URL('/resign')}}">Apply Resignation</a></li>
              @else
              <li><a href="{{URL('/resign')}}">View Resignation</a></li>
              @endif
            </ul>
          </li>
          
          {{-- <li class=""><a href="{{URL('logout')}}" class="waves-effect waves-button"><span class="menu-icon glyphicon glyphicon-home"></span><p>Logout</p></a></li> --}}
        </ul>
      </div><!-- Page Sidebar Inner -->
      </div><!-- Page Sidebar -->