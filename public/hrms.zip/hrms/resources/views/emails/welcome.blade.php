Hello {{$user->first_name}} <br><br>

This is your Reproter Id : {{$user->reporter_id}}<br>
Click here to activate your account <a href="{{URL('/activateAccount/'.$token)}}">Activate Now</a>
<br>
<br>
Thanks 