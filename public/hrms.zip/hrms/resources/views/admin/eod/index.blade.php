@extends('admin.layouts.app')
@section('content')
@section('title','EODs')

<div class="page-inner">
	<div class="page-title">
		<h3>EODs</h3>
		<div class="page-breadcrumb">
			<ol class="breadcrumb">
				<li><a href="{{URL('/admin/dashboard')}}">Home</a></li>
				<li class="active">All EODs</a></li>
			</ol>
		</div>
	</div>
	<div id="main-wrapper">
		<div class="row">
			<div class="col-md-12">
				@if (session('success'))
				<div class="alert alert-success">
					<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
					{{ session('success') }}
				</div>
				@endif
				@if (session('error'))
				<div class="alert alert-danger">
					<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
					{{ session('error') }}
				</div>
				@endif
				<div class="panel panel-white">
					<div class="panel-heading clearfix">
						<!-- <h4 class="panel-title">Sent EODs</h4> -->
					</div>
					<div class="panel-body">
						<div class="table-responsive table-remove-padding">
							<table class="table" id="datatable">
								<thead>
									<tr>
										<th>Employee</th>
										<th>Date</th>
										<th>Project Name</th>
										<th>Hours Spent</th>
										<th>Task</th>
										<th>Comment</th>
										<th>Action</th>
									</tr>
								</thead>
								<tbody>
									@foreach($eods as $eod)
									<tr>
										<td>{{$eod->date_of_eod}}</td>
										<td><a href="{{URL('/admin/employee/profile/'.$eod->user_id)}}">{{getUserById($eod->user_id)->first_name}}</a></td>
										<td>{{getProject($eod->project_id)->name}}</td>
										<td>{{$eod->hours_spent}}</td>
										<td>{{$eod->task}}</td>
										<td>
											@if(is_null($eod->comment))
											<b>N/A</b>
											@else
											{{$eod->comment}}
											@endif
										</td>
										<td>
											<a href="{{URL('admin/eod/delete/'.$eod->id)}}" class="btn btn-danger">Delete</a>
										</tr>
										@endforeach
									</tbody>
								</table>
							</div>
						</div>
					</div>
				</div>
			</div><!-- Row -->
		</div><!-- Main Wrapper -->
		<div class="page-footer">
			<p class="no-s">{{date('Y')}} &copy; Coding Brains Software Solution Pvt Ltd.</p>
		</div>
	</div><!-- Page Inner -->
	@section('script')
	@endsection
	@endsection