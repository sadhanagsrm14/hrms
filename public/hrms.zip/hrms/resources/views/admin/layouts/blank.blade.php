@extends('admin.layouts.app')
@section('content')
@section('title','Asset')

<div class="page-inner">
	<div class="page-title">
		<h3>Blank Page</h3>
		<div class="page-breadcrumb">
			<ol class="breadcrumb">
				<li><a href="index-2.html">Home</a></li>
				<li><a href="#">Layouts</a></li>
				<li class="active">Blank Page</li>
			</ol>
		</div>
	</div>
	<div id="main-wrapper">
		<div class="row">
		</div><!-- Row -->
	</div><!-- Main Wrapper -->
	<div class="page-footer">
		<p class="no-s">2015 &copy; Modern by Steelcoders.</p>
	</div>
</div><!-- Page Inner -->
@section('script')
@endsection
@endsection