<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AdminController extends Controller
{
	public function dashboard()
	{
		return view('admin.dashboard');
	}

	public function teams()
	{
		$team_leaders = array();
		$data = array();
		$team_leaders = \App\User::where('role',4)->with('personal_profile','cb_profile')->orderBy('id','DESC')->get();
		$data['team_leaders'] = $team_leaders;
		return view('admin.teams.teams',$data);
	}
	public function teamMembers($id)
	{
		$response = array();
		$team_members = \App\TeamMember::where('team_leader_id',$id)->orderBy('id','DESC')->get();
		if(count($team_members) > 0){
			$response['flag'] = true;
			$response['team_members'] = $team_members;
		}else{
			$response['flag'] = false;
		}
		return response()->json($response);
	}

	public function removeTeamMember($id)
	{
		$response = array();
		$team_member = \App\TeamMember::where('team_member_id',$id)->first();
		if(!is_null($team_member)){
			if($team_member->delete()){
				$response['flag'] = true;
			}else{
				$response['flag'] = false;
			}
		}else{
			$response['flag'] = false;
		}
		return response()->json($response);
	}
	
	public function getAddAssignTeam()
	{
		$team_members = \App\User::where('role',6)->with('personal_profile','cb_profile')->get();
		$team_leaders = \App\User::where('role',4)->with('personal_profile','cb_profile')->get();
		$data['team_members'] = $team_members;
		$data['team_leaders'] = $team_leaders;
		return view('admin.teams.assign-team-members',$data);
	}
	public function postAddAssignTeam(Request $request)
	{
		$validator = \Validator::make($request->all(),
			array(
				'team_leader' =>'required',
				'team_members' =>'required',
			)
		);
		if($validator->fails())
		{
			return redirect('/admin/assign-team-members')
			->withErrors($validator)
			->withInput();
		}
		else
		{
			$old = false;
			if(count($request->team_members) > 0) {
				$members = "";
				for ($i=0; $i < count($request->team_members) ; $i++) { 
					$team_member = new \App\TeamMember();
					$team_member->team_leader_id = $request->team_leader;
					$team_member->team_member_id = $request->team_members[$i];
					$old_team_member =  \App\TeamMember::where('team_member_id',$request->team_members[$i])->where('team_leader_id',$request->team_leader)->first();
					if(is_null($old_team_member)){
						$team_member->save();

						/*---------------------------------Send notification--------------------------*/
						$receiver = array($request->team_members[$i]);
						$title = "Admin Assigned You Team Leader ("." ".getUserById($request->team_leader)->first_name.')';
						$message = "Admin Assigned You Team Leader ("." ".getUserById($request->team_leader)->first_name.')';
						NotificationController::notify(\Auth::user()->id,$receiver,$title,$message);
						/*---------------------------------Send notification--------------------------*/

						/*---------------------------------Send notification--------------------------*/
						$receiver = array($request->team_leader);
						$title = "Admin Assigned You Team Member ("." ".getUserById($request->team_members[$i])->first_name.')';
						$message = "Admin Assigned You Team Member ("." ".getUserById($request->team_members[$i])->first_name.')';
						NotificationController::notify(\Auth::user()->id,$receiver,$title,$message);
						/*---------------------------------Send notification--------------------------*/

					}else{
						$members .= " ".getUserById($request->team_members[$i])->first_name.',';
						$old = true;
					}
				}
				if($old){
					$msg = "Operation executed successfully But Skipped some members(".$members.") because they are already Assigned.";
				}else{
					$msg = "Assigned Successfully";
				}
			}
			return redirect('/admin/assign-team-members')->with('success',$msg);
		}
	}

	public function resignations(Request $request)
	{

		$resignations = \App\Resignation::where('user_id','!=',\Auth::user()->id)->orderBy('id','DESC')->get();
		$data['resignations'] = $resignations;
		return view('admin.resignation.resignations',$data);
	}


}
