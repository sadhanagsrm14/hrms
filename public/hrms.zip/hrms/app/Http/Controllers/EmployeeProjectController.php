<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class EmployeeProjectController extends Controller
{
	public function employee_projects(){
		$employee_projects = \App\EmployeeProject::orderBy('id','DESC')->get();
		$data['employee_projects'] = $employee_projects;
		return view('admin.employee_projects.index',$data);
	}

	public function getAssignProject()
	{
		$projects = \App\Project::all();
		$employees = \App\User::where('role','!=',1)->where('role','!=',2)->get();
		$upperEmployees = \App\User::where('role','!=',6)->where('role','!=',1)->get();
		$data['projects'] = $projects;
		$data['employees'] = $employees;
		$data['upperEmployees'] = $upperEmployees;
		return view('admin.employee_projects.create',$data);
	} 
	public function postAssignProject(Request $request){
		$validator = \Validator::make($request->all(),
			array(
				'project' =>'required',
				'assign_to' =>'required',
				'reporting_to' =>'required',
				'from_date' =>'required',
				'end_date' =>'required',
				'project_status' =>'required',
			)
		);
		if($validator->fails())
		{
			return redirect('/admin/assign-project')
			->withErrors($validator)
			->withInput();
		}
		else
		{
			$old_employee_project =  \App\EmployeeProject::where('project_id',$request->project)->where('user_id',$request->assign_to)->first();
			if(is_null($old_employee_project)){
				$employee_project =  new \App\EmployeeProject();
				$employee_project->project_id = $request->project;
				$employee_project->user_id = $request->assign_to;
				$employee_project->reporting_to = $request->reporting_to;
				$employee_project->from_date = $request->from_date;
				$employee_project->end_date = $request->end_date;
				$employee_project->project_status = $request->project_status;
				if($request->feedback){
					$employee_project->feedback = $request->feedback;
				}
				if($employee_project->save()){ 
					/*--------------------------------Send Notification----------------------------------*/
					$title = "Admin Assigned you a New Project.";
					$message = "Admin Assigned you a New Project.";
					$receiver = array($request->assign_to);
					NotificationController::notify(\Auth::user()->id,$receiver,$title,$message);
					/*--------------------------------Send Notification----------------------------------*/
					return redirect('/admin/employee-projects')->with('success',"Added Successfully.");
				}else{
					return redirect('/admin/employee-projects')->with('error',"Something Went Wrong.");
				}
			}else{
				return redirect('/admin/employee-projects')->with('error',"Employee Is already assigned to this project ");
			}
			
		}

	}

	public function getEditEmployeeProject($id)
	{
		$employee_project = \App\EmployeeProject::where('id',$id)->first();
		if(is_null($employee_project)){
			return redirect('/admin/employee-projects')->with('error',"employee project Not found");
		}else{
			$projects = \App\Project::all();
			$employees = \App\User::where('role','!=',1)->where('role','!=',2)->get();
			$upperEmployees = \App\User::where('role','!=',6)->where('role','!=',1)->get();
			$data['projects'] = $projects;
			$data['employees'] = $employees;
			$data['upperEmployees'] = $upperEmployees;
			$data['employee_project'] = $employee_project;
			return view('admin.employee_projects.edit',$data);
		}
	} 
	public function postEditEmployeeProject(Request $request){
		$validator = \Validator::make($request->all(),
			array(
				'project' =>'required',
				'assign_to' =>'required',
				'reporting_to' =>'required',
				'from_date' =>'required',
				'end_date' =>'required',
				'project_status' =>'required',
			)
		);
		if($validator->fails())
		{
			return redirect()->back()
			->withErrors($validator)
			->withInput();
		}
		else
		{
			$employee_project =  \App\EmployeeProject::find($request->id);
			$employee_project->project_id = $request->project;
			$employee_project->user_id = $request->assign_to;
			$employee_project->reporting_to = $request->reporting_to;
			$employee_project->from_date = $request->from_date;
			$employee_project->end_date = $request->end_date;
			$employee_project->project_status = $request->project_status;
			if($request->feedback){
				$employee_project->feedback = $request->feedback;
			}
			if($employee_project->save()){ 
				$title = "Admin Assigned you a New Project.";
				$message = "Admin Assigned you a New Project.";
				$receiver = array($request->assign_to);
				NotificationController::notify(\Auth::user()->id,$receiver,$title,$message);
				return redirect('/admin/employee-projects')->with('success',"Updated Successfully");
			}else{
				return redirect('/admin/employee-projects')->with('error',"Something Went Wrong.");
			}
		}
	}

	public function deleteEmployeeProject($id)
	{
		$project = \App\EmployeeProject::find($id);
		if(is_null($project)){
			return redirect('/admin/employee-projects')->with('error','project Not Found');
		}else{
			if($project->delete()){
				return redirect('/admin/employee-projects')->with('success','Removed Successfully.');
			}else{
				return redirect('/admin/employee-projects')->with('error','Something Went Wrong');
			}
		}
	}
}
