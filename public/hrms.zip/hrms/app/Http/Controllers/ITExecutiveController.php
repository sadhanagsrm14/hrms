<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\AttendanceData;

class ITExecutiveController extends Controller
{
	public function dashboard()
	{
		return view('itExecutive.dashboard');
	} 

	public function getMasterAssetCode($master_id)
	{
		$master_system = \App\MasterAsset::where('id',$master_id)->first();
		$system_code = $master_system->system_code;
		return $system_code;
	} 
	public function getMasterSystem($master_id)
	{
		$master_system = \App\MasterAsset::where('id',$master_id)->first();
		return $master_system;
	} 
	public function getAssetAssoc($asset_id)
	{
		$asset_assoc = \App\AssetAssoc::where('id',$asset_id)->first();
		return $asset_assoc;
	} 

	public function assets()
	{
		$assets = \App\Asset::with('asset_type','master_asset','asset')->get();
		$data['assets'] = $assets;
		return view('itExecutive.asset.index',$data);
	} 
	public function getAddAsset()
	{
		$asset_types = \App\AssetType::all();
		$systems = \App\System::all();
		$data['systems'] = $systems;
		$data['asset_types'] = $asset_types;
		return view('itExecutive.asset.create',$data);
	} 
	public function postAddAsset(Request $request){
		$validator = \Validator::make($request->all(),
			array(
				'asset_type' =>'required',
				'asset' =>'required',
				'asset_status' =>'required',
			)
		);
		if($validator->fails())
		{
			return redirect('/itExecutive/add-asset')
			->withErrors($validator)
			->withInput();
		}
		else
		{
			$asset =  new \App\Asset();
			$asset_assoc = $this->getAssetAssoc($request->asset);
			$asset->asset_type_id = $request->asset_type;
			$asset->asset_id = $request->asset;
			$asset->name = $asset_assoc->name;
			if($request->s_no){
				$asset->s_no = $request->s_no;
			}
			if($request->purchase_bill_date){
				$asset->purchase_bill_date = $request->purchase_bill_date;
			}
			if($request->repair_replacement_date){
				$asset->repair_replacement_date = $request->repair_replacement_date;
			}
			$asset->is_warranty = $request->is_warranty;
			if($request->warranty_end_date){
				$asset->warranty_end_date = $request->warranty_end_date;
			}
			if($request->system_id){
				$asset->system_id = $request->system_id;
			}
			$asset->status = $request->asset_status;
			if($asset->save()){ 
				$updated_asset =   \App\Asset::find($asset->id);
				$updated_asset->asset_code =   $asset_assoc->asset_assoc_code.'00'.$asset->id;
				$updated_asset->save();
				if($request->system_id){
					$system_asset = new \App\SystemAsset();
					$system_asset->system_id = $request->system_id;
					$system_asset->asset_id =$asset->id;
					$system_asset->save();
				}
				return redirect('/itExecutive/assets')->with('success',"Added Successfully.");
			}else{
				return redirect('/itExecutive/assets')->with('error',"Something Went Wrong.");
			}
		}

	}

	public function getEditAsset($id)
	{
		$asset = \App\Asset::where('id',$id)->first();
		$asset_types = \App\AssetType::all();
		$systems = \App\System::all();
		$asset_assocs = \App\AssetAssoc::all();
		
		if(is_null($asset)){
			return redirect('/itExecutive/assets')->with('error',"asset Not found");
		}else{
			$data['asset'] = $asset;
			$data['systems'] = $systems;
			$data['asset_types'] = $asset_types;
			$data['asset_assocs'] = $asset_assocs;
			return view('itExecutive.asset.edit-asset',$data);
		}
	} 
	public function postEditAsset(Request $request){
		$validator = \Validator::make($request->all(),
			array(
				'asset_type' =>'required',
				'asset' =>'required',
				'asset_status' =>'required',
			)
		);
		if($validator->fails())
		{
			return redirect()->back()
			->withErrors($validator)
			->withInput();
		}
		else
		{
			$asset =  \App\Asset::find($request->id);
			$asset_assoc = $this->getAssetAssoc($request->asset);
			$asset->asset_type_id = $request->asset_type;
			$asset->asset_id = $request->asset;
			$asset->name = $asset_assoc->name;
			if($request->s_no){
				$asset->s_no = $request->s_no;
			}else{
				$asset->s_no = null;
			}
			if($request->purchase_bill_date){
				$asset->purchase_bill_date = $request->purchase_bill_date;
			}else{
				$asset->purchase_bill_date = null;
			}
			if($request->repair_replacement_date){
				$asset->repair_replacement_date = $request->repair_replacement_date;
			}else{
				$asset->repair_replacement_date = null;
			}
			$asset->is_warranty = $request->is_warranty;
			if($request->is_warranty){
				if($request->warranty_end_date){
					$asset->warranty_end_date = $request->warranty_end_date;
				}else{
					$asset->warranty_end_date = null;
				}
			}else{
				$asset->warranty_end_date = null;
			}
			if($request->system_id){
				$asset->system_id = $request->system_id;
			}else{
				$asset->system_id = null;
			}
			$asset->status = $request->asset_status;
			if($asset->save()){
				if($request->system_id){
					$system_asset =  \App\SystemAsset::where('asset_id',$request->id)->first();
					if(is_null($system_asset)){
						$system_asset =  new \App\SystemAsset();
					}
					$system_asset->system_id = $request->system_id;
					$system_asset->asset_id = $request->id;
					$system_asset->save();
				}
				return redirect('/itExecutive/assets')->with('success',"Updated Successfully");
			}else{
				return redirect('/itExecutive/assets')->with('error',"Something Went Wrong.");
			}
		}
	}

	public function releaseAsset($id)
	{
		$asset = \App\Asset::find($id);
		if(is_null($asset)){
			return redirect('/itExecutive/assets')->with('error','Asset Not Found');
		}else{
			$asset->user_id = NULL;
			$asset->status = "free";
			if($asset->save()){
				return redirect('/itExecutive/assets')->with('success','asset is Released Now.');
			}else{
				return redirect('/itExecutive/assets')->with('error','Something Went Wrong');
			}
		}
	}
	public function deleteAsset($id)
	{
		$asset = \App\Asset::find($id);
		if(is_null($asset)){
			return redirect('/itExecutive/assets')->with('error','asset Not Found');
		}else{
			if($asset->delete()){
				return redirect('/itExecutive/assets')->with('success','asset Removed Successfully.');
			}else{
				return redirect('/itExecutive/assets')->with('error','Something Went Wrong');
			}
		}
	}

	public function holidayCalender(Request $request)
	{
		$holidays = \App\Holiday::all();
		if($request->year){
			$data['year'] = $request->year;
		}else{
			$data['year'] = date('Y');
		}
		if($request->category){
			$data['category'] = $request->category;
		}else{
			$data['category'] = \Auth::user()->department;
		}
		return view('itExecutive.calender',$data);
	}

	public function exportAssetExcel()
	{
		$userExcel = \App\User::select('id as User Id','first_name as First Name','last_name as Last Name')->get();
		$assetExcel = \App\Asset::select('asset_code as Asset Code','name as Name','s_no as S.No','purchase_bill_date as Purchase/Bill date','is_warranty as Warranty','warranty_end_date as Warranty End Date','system_id as System Id','status as Status')->get();
		$assetTypeExcel = \App\AssetType::select('id as Asset Type Id','type as Asset Type')->get();
		$AssetAssocExcel = \App\AssetAssoc::select('id as Asset Id','name as Asset Name')->get();
		\Excel::create('Asset Lists', function($excel) use($assetExcel,$assetTypeExcel,$AssetAssocExcel,$userExcel) {
			$excel->sheet('Sheet 1', function($sheet) use($assetExcel) {
				$sheet->fromArray($assetExcel);
			});
			$excel->sheet('Asset Type', function($sheet) use($assetTypeExcel) {
				$sheet->fromArray($assetTypeExcel);
			});
			$excel->sheet('Assets Assoc', function($sheet) use($AssetAssocExcel) {
				$sheet->fromArray($AssetAssocExcel);
			});
			$excel->sheet('Users', function($sheet) use($userExcel) {
				$sheet->fromArray($userExcel);
			});
		})->export('xls');
	}
	public function exportSystemExcel()
	{
		$systemExcel = \App\System::select('id as System Id','system_id as Unique Id','name as System Name')->get();
		\Excel::create('System Lists', function($excel) use($systemExcel) {
			$excel->sheet('Sheet 1', function($sheet) use($systemExcel) {
				$sheet->fromArray($systemExcel);
			});
			
		})->export('xls');
	}
	public function importAssetExcel(Request $request)
	{
		$response = array();
		if($request->hasFile('assetFile'))
		{
			$extension = \File::extension($request->file('assetFile')->getClientOriginalName());
			if ($extension == "xlsx" || $extension == "xls" || $extension == "csv") {
				\Excel::load($request->file('assetFile'), function($reader) {
					$reader->each(function ($sheet)
					{
						$asset = \App\Asset::find($sheet->id);
						$new = false;
						if(is_null($asset)){
							$asset = new \App\Asset();
							$new = true;
						}
						$asset_assoc = $this->getAssetAssoc($sheet->asset_id);
						$asset->asset_type_id = $sheet->asset_type_id;
						$asset->asset_id = $sheet->asset_id;
						$asset->name = $asset_assoc->name;
						if($sheet->s_no){
							$asset->s_no = $sheet->s_no;
						}
						if($sheet->purchase_bill_date){
							$asset->purchase_bill_date = $sheet->purchase_bill_date;
						}
						if($sheet->repair_replacement_date){
							$asset->repair_replacement_date = $sheet->repair_replacement_date;
						}
						$asset->is_warranty = $sheet->is_warranty;
						if($sheet->warranty_end_date){
							$asset->warranty_end_date = $sheet->warranty_end_date;
						}
						if($sheet->system_id){
							$asset->system_id = $sheet->system_id;
							$asset->status = "assigned"; 
						}else{
							$asset->system_id = null;
							$asset->status = "free"; 
						}
						if($asset->save()){
							if($new){
								$updated_asset =   \App\Asset::find($asset->id);
								$updated_asset->asset_code =   $asset_assoc->asset_assoc_code.'00'.$asset->id;
								$updated_asset->save();
								if($sheet->system_id){
									$system_asset = new \App\SystemAsset();
									$system_asset->system_id = $sheet->system_id;
									$system_asset->asset_id = $asset->id;
									$system_asset->save();
								}
							}
						} 
					});
				});
				$response['flag'] = true;
				$response['message'] = "Uploaded Successfully.";
			}else {
				$response['flag'] = false;
				$response['error'] = 'Invalid file';
			}
			return response()->json($response);
		}
	}

	public function systems()
	{
		$systems = \App\System::all();
		$employees = \App\User::where('role','!=',1)->with('personal_profile','cb_profile')->get();
		$data['systems'] = $systems;
		return view('itExecutive.asset.systems',$data);
	} 
	public function getAddSystem()
	{
		$asset_types = \App\AssetType::all();
		$employees = \App\User::where('role','!=',1)->with('personal_profile','cb_profile')->get();
		$data['employees'] = $employees;
		$data['asset_types'] = $asset_types;
		return view('itExecutive.asset.create-system',$data);
	} 
	public function postAddSystem(Request $request){
		$validator = \Validator::make($request->all(),
			array(
				'asset_type' =>'required',
				'system_name' =>'required',
			)
		);
		if($validator->fails())
		{
			return redirect('/itExecutive/add-system')
			->withErrors($validator)
			->withInput();
		}
		else
		{
			$system =  new \App\System();
			$master_system = $this->getMasterSystem($request->system_name);
			$system->master_system_id = $request->system_name;
			$system->asset_type_id = $request->asset_type;
			$system->name = $master_system->name;
			if($request->assign_to){
				$system->assign_to = $request->assign_to;
			}
			if($system->save()){ 
				$updated_system =   \App\System::find($system->id);
				$updated_system->system_id = $master_system->asset_code.'00'.$system->id;
				$updated_system->save();
				/*---------------------------------Send notification--------------------------*/
				if($request->assign_to){
					$receiver = array($request->assign_to);
					$title = "IT Asset Manager Assigned You System"." ".$updated_system->system_id;
					$message = "IT Asset Manager Assigned You System"." ".$updated_system->system_id;
					NotificationController::notify(\Auth::user()->id,$receiver,$title,$message);
					$admin_receiver = array();
					$admins = \App\User::where('role','1')->get();
					foreach ($admins as $admin) {
						array_push($admin_receiver,$admin->id);
					}
					$title1 = "IT Asset Manager Assigned System"." ".$updated_system->system_id ." to ".getUserById($request->assign_to)->first_name.' '.getUserById($request->assign_to)->last_name;
					$message1 = "IT Asset Manager Assigned System"." ".$updated_system->system_id ." to ".getUserById($request->assign_to)->first_name.' '.getUserById($request->assign_to)->last_name;
					NotificationController::notify(\Auth::user()->id,$admin_receiver,$title1,$message1);

				}
				/*---------------------------------Send notification--------------------------*/


				return redirect('/itExecutive/systems')->with('success',"Added Successfully.");
			}else{
				return redirect('/itExecutive/systems')->with('error',"Something Went Wrong.");
			}
		}

	}

	public function getEditSystem($id)
	{
		$system = \App\System::where('id',$id)->with('assets')->first();
		$asset_types = \App\AssetType::all();
		$system_names = \App\MasterAsset::all();
		$employees = \App\User::where('role','!=',1)->with('personal_profile','cb_profile')->get();
		if(is_null($system)){
			return redirect('/itExecutive/systems')->with('error',"system Not found");
		}else{
			$data['system'] = $system;
			$data['employees'] = $employees;
			$data['asset_types'] = $asset_types;
			$data['system_names'] = $system_names;
			return view('itExecutive.asset.edit-system',$data);
		}
	} 
	public function postEditSystem(Request $request){
		
		$system =  \App\System::find($request->id);
		$old_owner = $system->assign_to;
		if($request->assign_to){
			$system->assign_to = $request->assign_to;
		}else{
			$system->assign_to = null;
		}
		if($system->save()){
			/*---------------------------------Send notification--------------------------*/
			if($request->assign_to && $request->assign_to != $old_owner){
				$receiver = array($request->assign_to);
				$title = "IT Asset Manager Assigned You System"." ".$system->system_id;
				$message = "IT Asset Manager Assigned You System"." ".$system->system_id;
				NotificationController::notify(\Auth::user()->id,$receiver,$title,$message);

				if(!is_null($old_owner)){
					$old_receiver = array($old_owner);
					$old_title = "IT Asset Manager Released Your System"." ".$system->system_id;
					$old_message = "IT Asset Manager Released Your System"." ".$system->system_id;
					NotificationController::notify(\Auth::user()->id,$old_receiver,$old_title,$old_message);
				}
				$admin_receiver = array();
				$admins = \App\User::where('role','1')->get();
				foreach ($admins as $admin) {
					array_push($admin_receiver,$admin->id);
				}
				$title1 = "IT Asset Manager Assigned System"." ".$system->system_id ." to ".getUserById($request->assign_to)->first_name.' '.getUserById($request->assign_to)->last_name;
				$message1 = "IT Asset Manager Assigned System"." ".$system->system_id ." to ".getUserById($request->assign_to)->first_name.' '.getUserById($request->assign_to)->last_name;
				NotificationController::notify(\Auth::user()->id,$admin_receiver,$title1,$message1);

			}
			if(is_null($system->assign_to)){
				$receiver = array($old_owner);
				$title = "IT Asset Manager Released Your System"." ".$system->system_id;
				$message = "IT Asset Manager Released Your System"." ".$system->system_id;
				NotificationController::notify(\Auth::user()->id,$receiver,$title,$message);

				$admin_receiver = array();
				$admins = \App\User::where('role','1')->get();
				foreach ($admins as $admin) {
					array_push($admin_receiver,$admin->id);
				}
				$title1 = "IT Asset Manager Released System"." ".$system->system_id ." from ".getUserById($old_owner)->first_name.' '.getUserById($old_owner)->last_name;
				$message1 = "IT Asset Manager Released System"." ".$system->system_id ." from ".getUserById($old_owner)->first_name.' '.getUserById($old_owner)->last_name;
				NotificationController::notify(\Auth::user()->id,$admin_receiver,$title1,$message1);

			}

			/*---------------------------------Send notification--------------------------*/
			return redirect('/itExecutive/systems')->with('success',"Updated Successfully");
		}else{
			return redirect('/itExecutive/systems')->with('error',"Something Went Wrong.");
		}
	}
	public function releaseSystemAsset($system_id,$id){
		$systemAsset = \App\SystemAsset::find($id);
		if(is_null($systemAsset)){
			return redirect('/itExecutive/system/'.$system_id)->with('error','Association Not Found');
		}else{
			if($systemAsset->delete()){
				$asset = \App\Asset::where('id',$systemAsset->asset_id)->first();
				$asset->system_id =  null;
				$asset->status =  "free";
				$asset->save();
				return redirect('/itExecutive/system/'.$system_id)->with('success','Asset Release Successfully.');
			}else{
				return redirect('/itExecutive/system/'.$system_id)->with('error','Something Went Wrong');
			}
		}
	}
	public function addAttendance(Request $request){

		$is_added = AttendanceData::where('attendance_date',$request->mydate)->where('employee_id',$request->employee_id)->first(); 
		if(count($is_added) == 1){
			$attendance_data = AttendanceData::find($is_added->id);				
		}else{
			$attendance_data = new AttendanceData();				
		}	
		$attendance_data->attendance_date = $request->mydate;
		$attendance_data->status = "P";
		$attendance_data->employee_id =$request->employee_id;
		if($attendance_data->save()){
			$data["success"] = true;
		}else{
			$data["success"] = false;			
		}	
		return json_encode($data);
	}

	public function myLeaves(Request $request)
	{
		if($request->type){
			if($request->type == 'approved'){
				$is_approved = 1;
			}
			elseif($request->type == 'pending'){
				$is_approved = 0;
			}
			elseif($request->type == 'rejected'){
				$is_approved = -1;
			}
			$leaves = \App\Leaves::where('user_id',\Auth::user()->id)->where('is_approved',$is_approved)->with('leave_type')->get();
		}else{
			$leaves = \App\Leaves::where('user_id',\Auth::user()->id)->with('leave_type')->get();
		}
		$data['leaves'] = $leaves;
		return view('itExecutive.leaves.index',$data);
	} 
	public function getAddLeave()
	{
		$leave_types = \App\LeaveType::all();
		$data['leave_types'] = $leave_types;
		return view('itExecutive.leaves.apply-leave',$data);
	} 
	public function postAddLeave(Request $request){
		$validator = \Validator::make($request->all(),
			array(
				'leave_type' =>'required',
				'date_from' =>'required',
				'date_to' =>'required',
				'contact_number' =>'required',
				'reason' =>'required',
			)
		);
		if($validator->fails())
		{
			return redirect('/itExecutive/apply-leave')
			->withErrors($validator)
			->withInput();
		}
		else
		{
			$leave =  new \App\Leaves();
			$leave->user_id = \Auth::user()->id;
			$leave->leave_type_id = $request->leave_type;
			$leave->date_from = $request->date_from;
			$leave->date_to = $request->date_to;
			$leave->days = $request->days;
			$leave->contact_number = $request->contact_number;
			$leave->reason = $request->reason;
			$url = url('role/leave-listing?type=pending');
			if($leave->save()){ 
				/*-----------------------------------Send notification-------------------------------------------*/
				$user = \App\User::where('id',\Auth::user()->id)->first();
				$receiver = array();
				$title = $user->first_name." ".$user->last_name." "."Requested for Leave";
				$message = $user->first_name." ".$user->last_name." "."Requested for Leave."."<br>";
				$message.= "<a href='".$url."' class='btn btn-primary'>view</a>";
				$admins = \App\User::where('role','1')->get();
				foreach ($admins as $admin) {
					array_push($receiver,$admin->id);
				}
				$hrs = \App\User::where('role','2')->get();
				foreach ($hrs as $hr) {
					array_push($receiver,$hr->id);
				}
				NotificationController::notify(\Auth::user()->id,$receiver,$title,$message);
				/*-----------------------------------Send notification-------------------------------------------*/
				return redirect('/itExecutive/my-leaves')->with('success',"Added Successfully.");
			}else{
				return redirect('/itExecutive/my-leaves')->with('error',"Something Went Wrong.");
			}
		}

	}

	// public function sent_eod()
	// {
	// 	$sent_eod = \App\Eod::where('user_id',\Auth::user()->id)->get();
	// 	$data['eods'] = $sent_eod;
	// 	return view('itExecutive.eod.index',$data);
	// } 
	// public function getSendEOD()
	// {
	// 	return view('itExecutive.eod.send-eod');
	// } 
	// public function postSendEOD(Request $request){
	// 	$validator = \Validator::make($request->all(),
	// 		array(
	// 			'project_name' =>'required',
	// 			'hours_spent' =>'required',
	// 			'comments' =>'required',
	// 		)
	// 	);
	// 	if($validator->fails())
	// 	{
	// 		return redirect('/itExecutive/send-eod')
	// 		->withErrors($validator)
	// 		->withInput();
	// 	}
	// 	else
	// 	{
	// 		$eod =  new \App\Eod();
	// 		$eod->user_id = \Auth::user()->id;
	// 		$eod->project_name = $request->project_name;
	// 		$eod->hours_spent = $request->hours_spent;
	// 		$eod->comments = $request->comments;
	// 		if($eod->save()){ 
	// 			return redirect('/itExecutive/sent-eods')->with('success',"Sent Successfully.");
	// 		}else{
	// 			return redirect('/itExecutive/sent-eods')->with('error',"Something Went Wrong.");
	// 		}
	// 	}

	// }

	// public function getEOD($id)
	// {
	// 	$eod = \App\Eod::where('id',$id)->first();
	// 	if(is_null($eod)){
	// 		return redirect('/itExecutive/sent-eods')->with('error',"eod Not found");
	// 	}else{
	// 		$data['eod'] = $eod;
	// 		return view('itExecutive.eod.edit',$data);
	// 	}
	// } 

	public function getProfile()
	{
		$data = array();
		$data['employee'] = \App\User::where('id',\Auth::user()->id)->with('personal_profile','cb_profile','previous_employment','cb_appraisal_detail')->first();
		return view('itExecutive.profile.index',$data);
	}

	public function getProfileEdit()
	{
		$data = array();
		$data['employee'] = \App\User::where('id',\Auth::user()->id)->with('personal_profile','cb_profile','previous_employment','cb_appraisal_detail')->first();
		return view('itExecutive.profile.edit',$data);
	}
	public function postProfileEdit(Request $request)
	{
		$user_array['first_name'] = $request->first_name;
		$user_array['last_name'] = $request->last_name;
		$user_array['address'] = $request->address;
		$user_array['phone_number'] = $request->phone_number;
		$user_array['bank_account'] = $request->account_no;
		$user_array['martial_status'] = $request->martial_status;
		$user_array['dob'] = $request->dob;
		$user_array['anniversary_date'] = $request->anniversary_date;
		$user_array['personal_email'] = $request->personal_email;
		$user_array['father_name'] = $request->father_name;
		$user_array['mother_name'] = $request->mother_name;
		$user_array['parent_contact_number'] = $request->parent_number;
		$user = \App\User::where('id',\Auth::user()->id)->first();
		$user->request_json = json_encode($user_array);
		$user->is_request_approved = 0;
		$url = url('role/request/profile/'.$user->id);
		if($user->save()){
			/*-----------------------------------Send notification-------------------------------------------*/
			$receiver = array();
			$title = $user->first_name." ".$user->last_name." "."Requested For profile update.";
			$message = $user->first_name." ".$user->last_name." "."Requested For profile update."."<br>";
			$message.= "<a href='".$url."' class='btn btn-primary'>view</a>";
			$admins = \App\User::where('role','1')->get();
			foreach ($admins as $admin) {
				array_push($receiver,$admin->id);
			}
			$hrs = \App\User::where('role','2')->get();
			foreach ($hrs as $hr) {
				array_push($receiver,$hr->id);
			}
			NotificationController::notify(\Auth::user()->id,$receiver,$title,$message);
			/*-----------------------------------Send notification-------------------------------------------*/
			return redirect('/profile')->with('success','Request Sent Successfully.Waiting approval from admin.');
		}
	}
}
