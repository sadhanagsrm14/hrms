<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ProjectController extends Controller
{
	public function projects()
	{
		$projects = \App\Project::all();
		$data['projects'] = $projects;
		return view('admin.projects.index',$data);
	} 
	public function getAddProject()
	{
		return view('admin.projects.create');
	} 
	public function postAddProject(Request $request){
		$validator = \Validator::make($request->all(),
			array(
				'project_name' =>'required',
				'start_date' =>'required',
			)
		);
		if($validator->fails())
		{
			return redirect('/admin/add-project')
			->withErrors($validator)
			->withInput();
		}
		else
		{
			$project =  new \App\Project();
			$project->name = $request->project_name;
			$project->start_date = $request->start_date;
			if($request->end_date){
				$project->end_date = $request->end_date;
			}
			if($request->client_name){
				$project->client_name = $request->client_name;
			}	
			if($request->project_comments){
				$project->project_comments = $request->project_comments;
			}
			if($project->save()){ 
				$update_project = \App\Project::find($project->id);
				$update_project->project_id = 'PROJECT00'.$project->id;
				$update_project->save();
				return redirect('/admin/projects')->with('success',"Added Successfully.");
			}else{
				return redirect('/admin/projects')->with('error',"Something Went Wrong.");
			}
		}

	}

	public function getEditProject($id)
	{
		$project = \App\Project::where('id',$id)->first();
		if(is_null($project)){
			return redirect('/admin/projects')->with('error',"project Not found");
		}else{
			$data['project'] = $project;
			return view('admin.projects.edit',$data);
		}
	} 
	public function postEditProject(Request $request){
		$validator = \Validator::make($request->all(),
			array(
				'project_name' =>'required',
				'start_date' =>'required',
			)
		);
		if($validator->fails())
		{
			return redirect()->back()
			->withErrors($validator)
			->withInput();
		}
		else
		{
			$project =  \App\Project::find($request->id);
			$project->name = $request->project_name;
			$project->start_date = $request->start_date;
			if($request->end_date){
				$project->end_date = $request->end_date;
			}
			if($request->client_name){
				$project->client_name = $request->client_name;
			}	
			if($request->project_comments){
				$project->project_comments = $request->project_comments;
			}
			if($project->save()){
				return redirect('/admin/projects')->with('success',"Updated Successfully");
			}else{
				return redirect('/admin/projects')->with('error',"Something Went Wrong.");
			}
		}
	}

	public function deleteProject($id)
	{
		$project = \App\Project::find($id);
		if(is_null($project)){
			return redirect('/admin/projects')->with('error','project Not Found');
		}else{
			if($project->delete()){
				return redirect('/admin/projects')->with('success','Removed Successfully.');
			}else{
				return redirect('/admin/projects')->with('error','Something Went Wrong');
			}
		}
	}
}
