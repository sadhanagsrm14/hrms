<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AdminLeaveController extends Controller
{
	public function leave_listing(Request $request)
	{
		if($request->type == "approved"){
			$leaves = \App\Leaves::where('is_approved',1)->with('leave_type')->get();
		}else if($request->type == "discarded"){
			$leaves = \App\Leaves::where('is_approved',-1)->with('leave_type')->get();
		}
		else if($request->type == "pending"){
			$leaves = \App\Leaves::where('is_approved',0)->with('leave_type')->get();
		}else{
			$leaves = \App\Leaves::all();
		}
		$data['leaves'] = $leaves;
		return view('admin.leaves.leaves',$data);
	} 
	public function leave_types()
	{
		$leave_types = \App\LeaveType::all();
		$data['leave_types'] = $leave_types;
		return view('admin.leaves.leave_types',$data);
	} 
	public function getAddLeaveType()
	{
		return view('admin.leaves.create_leaves_type');
	} 
	public function postAddLeaveType(Request $request){
		$validator = \Validator::make($request->all(),
			array(
				'leave_type' =>'required',
				'description' =>'required',
			)
		);
		if($validator->fails())
		{
			return redirect('/admin/add-leave-type')
			->withErrors($validator)
			->withInput();
		}
		else
		{
			$leave_type =  new \App\LeaveType();
			$leave_type->leave_type = $request->leave_type;
			$leave_type->description = $request->description;
			if($leave_type->save()){ 
				return redirect('/admin/leave-types')->with('success',"Added Successfully.");
			}else{
				return redirect('/admin/leave-types')->with('error',"Something Went Wrong.");
			}
		}

	}

	public function getEditLeaveType($id)
	{
		$leave_type = \App\LeaveType::where('id',$id)->first();
		if(is_null($leave_type)){
			return redirect('/admin/leave-types')->with('error',"leave_type Not found");
		}else{
			$data['leave_type'] = $leave_type;
			return view('admin.leaves.edit_leaves_type',$data);
		}
	} 
	public function postEditLeaveType(Request $request){
		$validator = \Validator::make($request->all(),
			array(
				'leave_type' =>'required',
				'description' =>'required',
			)
		);
		if($validator->fails())
		{
			return redirect()->back()
			->withErrors($validator)
			->withInput();
		}
		else
		{
			$leave_type =  \App\LeaveType::find($request->id);
			$leave_type->leave_type = $request->leave_type;
			$leave_type->description = $request->description;
			if($leave_type->save()){
				return redirect('/admin/leave-types')->with('success',"Updated Successfully");
			}else{
				return redirect('/admin/leave-types')->with('error',"Something Went Wrong.");
			}
		}
	}

	public function deleteLeaveType($id)
	{
		$leave_type = \App\LeaveType::find($id);
		if(is_null($leave_type)){
			return redirect('/admin/leave-types')->with('error','leave type Not Found');
		}else{
			if($leave_type->delete()){
				return redirect('/admin/leave-types')->with('success','leave type Removed Successfully.');
			}else{
				return redirect('/admin/leave-types')->with('error','Something Went Wrong');
			}
		}
	}

	public function approveLeave($id)
	{
		$leave = \App\Leaves::find($id);
		if(is_null($leave)){
			return redirect('/admin/leave-listing')->with('error','Leave Not Found');
		}else{
			$leave->is_approved = 1;
			$employee_cb_profile =   \App\EmployeeCbProfile::where('user_id',$leave->user_id)->first();
			$remainDays = ($employee_cb_profile->avail_leaves - $leave->days);
			if($remainDays < 0){
				$employee_cb_profile->avail_leaves = 0;
				$employee_cb_profile->leaves_taken =  ($employee_cb_profile->leaves_taken + abs($remainDays));
			}else{
				$employee_cb_profile->avail_leaves = $remainDays;
			}
			
			if($leave->save()){
				$employee_cb_profile->save();
				/*-----------------------------------Send notification-------------------------------------------*/
				$receiver = array($leave->user_id);
				$title = "Admin Accepted You leave request.";
				$message = "Admin Accepted You leave request.";
				$admins = \App\User::where('role','1')->get();
				NotificationController::notify(\Auth::user()->id,$receiver,$title,$message);
				/*-----------------------------------Send notification-------------------------------------------*/
				return redirect('/admin/leave-listing')->with('success','Leave Status Updated Successfully.');
			}else{
				return redirect('/admin/leave-listing')->with('error','Something Went Wrong');
			}
		}
	}

	public function discardLeave($id)
	{
		$leave = \App\Leaves::find($id);
		if(is_null($leave)){
			return redirect('/admin/leave-listing')->with('error','Leave Not Found');
		}else{
			$leave->is_approved = -1;
			if($leave->save()){
				/*-----------------------------------Send notification-------------------------------------------*/
				$receiver = array($leave->user_id);
				$title = "Admin Discarded You leave request.";
				$message = "Admin Discarded You leave request.";
				$admins = \App\User::where('role','1')->get();
				NotificationController::notify(\Auth::user()->id,$receiver,$title,$message);
				/*-----------------------------------Send notification-------------------------------------------*/
				return redirect('/admin/leave-listing')->with('success','Leave Status Updated Successfully.');
			}else{
				return redirect('/admin/leave-listing')->with('error','Something Went Wrong');
			}
		}
	}

	public function deleteLeave($id)
	{
		$leave = \App\Leaves::find($id);
		if(is_null($leave)){
			return redirect()->back()->with('error','Leave Not Found');
		}else{
			if($leave->delete()){
				return redirect()->back()->with('success','Leave Removed Successfully.');
			}else{
				return redirect()->back()->with('error','Something Went Wrong');
			}
		}
	}
}
