<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
class ResignController extends Controller
{
	public function getRole(){
		if(Auth::check()){
			if(Auth::user()->role == 1){
				return "admin";
			}
			if(Auth::user()->role == 2){
				return "hrManager";
			}
			if(Auth::user()->role == 3){
				return "hrExecutive";
			}
			if(Auth::user()->role == 4){
				return "employee";
			}
			if(Auth::user()->role == 5){
				return "itExecutive";
			}
			if(Auth::user()->role == 6){
				return "employee";
			}
		}
	}

	public function resignations()
	{
		$data = array();
		$data['resignations'] = \App\Resignation::where('user_id',\Auth::user()->id)->orderBy('id','DESC')->get();
		return view($this->getRole().'.resignation.index',$data);
	}

	public function getApplyResign()
	{
		$data = array();
		$resign = \Auth::user()->resignation;
		if(!is_null($resign)){
			$data['resign'] = $resign;
			return view($this->getRole().'.resignation.resign',$data);
		}else{
			$data['notice_period'] = \Auth::user()->cb_profile->notice_period;
			$data['date_of_resign'] = date('Y-m-d');
			$data['last_working_day'] =  date('Y-m-d', strtotime($data['date_of_resign']. ' + '.$data['notice_period'].' days'));
			$data['fnf_date'] =  date('Y-m-d', strtotime($data['last_working_day']. ' + 45 days'));
			$data['current_projects'] = \App\EmployeeProject::where('user_id',\Auth::user()->id)->where('project_status',0)->orderBy('id','DESC')->get();
			$data['reporting_managers'] = \App\TeamMember::where('team_member_id',\Auth::user()->id)->orderBy('id','DESC')->get();
			return view($this->getRole().'.resignation.apply-resign',$data);
		}
	}


	public function postApplyResign(Request $request)
	{
		$validator = \Validator::make($request->all(),
			array(
				'reason' =>'required',
				'message' =>'required',
			)
		);
		if($validator->fails())
		{
			return redirect('/resign')
			->withErrors($validator)
			->withInput();
		}
		else
		{
			$resignation = new \App\Resignation();
			$resignation->user_id = \Auth::user()->id;
			$resignation->date_of_resign = $request->date_of_resign;
			$resignation->last_working_day = $request->last_working_day;
			$resignation->fnf_date = $request->fnf_date;
			if($request->reporting_manager){
				$resignation->manager_id = $request->reporting_manager;
			}
			if($request->current_project){
				$resignation->current_project_id = $request->current_project;
			}
			$resignation->reason = $request->reason;
			$resignation->message = $request->message;
			$resignation->is_active = 1;
			if($resignation->save()){

				/*-----------------------------------Send notification-------------------------------------------*/
				$user = \App\User::where('id',\Auth::user()->id)->first();
				$receiver = array();
				$receiver_email = array();
				$title = $user->first_name." ".$user->last_name." "."Applied Resignation";
				$message = $user->first_name." ".$user->last_name." "."Applied Resignation.";
				$admins = \App\User::where('role','1')->get();
				foreach ($admins as $admin) {
					array_push($receiver,$admin->id);
					array_push($receiver_email,$admin->email);
				}
				if($user->role != 2){
					$hrs = \App\User::where('role','2')->get();
					foreach ($hrs as $hr) {
						array_push($receiver,$hr->id);
						array_push($receiver_email,$hr->email);
					}
				}
				NotificationController::notify(\Auth::user()->id,$receiver,$title,$message);
				/*-----------------------------------Send notification------------------------------------*/

				$templateData['user'] = \App\User::where('id',\Auth::user()->id)->with('personal_profile','cb_profile')->first();
				
				$templateData['resign'] = $resignation;
				$MailData = new \stdClass();
				$MailData->subject ='Resignation Letter - '.\Auth::user()->first_name.' '.\Auth::user()->last_name;
				$MailData->sender_email = \Auth::user()->email;
				$MailData->sender_name = \Auth::user()->first_name.' '.\Auth::user()->last_name;
				$MailData->receiver_email = $receiver_email;
				$MailData->receiver_name = \Auth::user()->email;
				MailController::sendMail('resignation_letter',$templateData,$MailData);

				return redirect('/resign/')->with('success',"Resignation Submitted Successfully");
				
			}
		}
	}

	public function previewResign($id)
	{
		$response = array();
		$resign = \App\Resignation::find($id);
		if(is_null($resign)){
			$response['flag'] = false;
			$response['message'] = "Resignation not Found";
		}else{
			$response['flag'] = true;
			$response['resign'] = $resign;
		}
		return response()->json($response);
	}
	
	public function retractResign($id)
	{
		$resign = \App\Resignation::find($id);
		if(is_null($resign)){
			return redirect()->back()->with('error',"Resignation not Found");
		}else{
			if($resign->delete()){
				/*-----------------------------------Send notification-------------------------------------------*/
				$user = \App\User::where('id',\Auth::user()->id)->first();
				$receiver = array();
				$receiver_email = array();
				$title = $user->first_name." ".$user->last_name." "."Retracted Applied Resignation";
				$message = $user->first_name." ".$user->last_name." "."Retracted Applied Resignation.";
				$admins = \App\User::where('role','1')->get();
				foreach ($admins as $admin) {
					array_push($receiver,$admin->id);
					array_push($receiver_email,$admin->email);
				}
				if($user->role != 2){
					$hrs = \App\User::where('role','2')->get();
					foreach ($hrs as $hr) {
						array_push($receiver,$hr->id);
						array_push($receiver_email,$hr->email);
					}
				}
				NotificationController::notify(\Auth::user()->id,$receiver,$title,$message);
				/*-----------------------------------Send notification-------------------------------------------*/

				$templateData['user'] = \App\User::where('id',\Auth::user()->id)->with('personal_profile','cb_profile')->first();
				
				$templateData['resign'] = $resign;
				$MailData = new \stdClass();
				$MailData->subject ='Resignation Retracted - '.\Auth::user()->first_name.' '.\Auth::user()->last_name;
				$MailData->sender_email = \Auth::user()->email;
				$MailData->sender_name = \Auth::user()->first_name.' '.\Auth::user()->last_name;
				$MailData->receiver_email = $receiver_email;
				$MailData->receiver_name = \Auth::user()->email;
				// MailController::sendMail('resignation_retracted',$templateData,$MailData);

				return redirect('/resign')->with('success',"Resignation Retracted and Application Deleted Successfully");
			}else{
				
			}
		}
	}

	public function submitResign($id)
	{
		$resign = \App\Resignation::find($id);
		if(is_null($resign)){
			return redirect()->back()->with('error',"Resignation not Found");
		}else{
			$resign->is_active = 1;
			if($resign->save()){
				
				$templateData['user'] = \App\User::where('id',\Auth::user()->id)->with('personal_profile','cb_profile')->first();
				
				$templateData['resign'] = $resign;
				$MailData = new \stdClass();
				$MailData->subject ='Resignation Letter - '.\Auth::user()->first_name.' '.\Auth::user()->last_name;
				$MailData->sender_email = \Auth::user()->email;
				$MailData->sender_name = \Auth::user()->first_name.' '.\Auth::user()->last_name;
				$MailData->receiver_email = $receiver_email;
				$MailData->receiver_name = \Auth::user()->email;
				MailController::sendMail('resignation_letter',$templateData,$MailData);
				return redirect('/resignations')->with('success',"Resignation Submitted Successfully");
			}else{
				
			}
		}
	}
}
