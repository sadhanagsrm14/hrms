<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AjaxController extends Controller
{
	public function getMasterAssetByType($type_id){
		$master_assets = \App\MasterAsset::where('asset_type_id',$type_id)->get();
		return response()->json($master_assets);
	}
	public function getAssetByAssetType($type_id){
		$master_assets = \App\AssetAssoc::where('asset_type_id',$type_id)->get();
		return response()->json($master_assets);
	}
	public function freeAssets($type_id,$asset_id){
		$free_assets = \App\Asset::where('asset_type_id',$type_id)->where('asset_id',$asset_id)->where('system_id',null)->where('status','free')->get();
		return response()->json($free_assets);
	}
	public function getAssetsByTypeMaster($type_id,$master_type){
		$master_assets = \App\AssetAssoc::where('asset_type_id',$type_id)->where('master_asset_id',$master_type)->get();
		return response()->json($master_assets);
	}
	public function assignAsset($system_id,$asset_id){
		$response = array();
		$result = \App\SystemAsset::where('system_id',$system_id)->where('asset_id',$asset_id)->first();
		if(!is_null($result)){
			$response['flag'] = false;
			$response['error'] = "Already Assigned";
		}else{
			$system_asset = new \App\SystemAsset();
			$system_asset->system_id = $system_id;
			$system_asset->asset_id = $asset_id;
			if($system_asset->save()){
				$asset = \App\Asset::where('id',$asset_id)->first();
				$asset->system_id =  $system_id;
				$asset->status =  "assigned";
				$asset->save();
				$response['flag'] = true;
			}else{
				$response['flag'] = false;
				$response['error'] = "Something Went wrong.";
			}
		}
		
		return response()->json($response);

	}

	public function releaseAsset($id)
	{
		$response = array();
		$asset = \App\Asset::find($id);
		$asset->user_id = NULL;
		$asset->status = "free";
		if($asset->save()){
			$response['flag'] = true;
		}else{
			$response['flag'] = false;
		}
		return response()->json($response);
	}
	public function getSystem($id)
	{
		$response = array();
		$system = \App\System::where('id',$id)->with('assets')->first();
		if(is_null($system)){
			$response['flag'] = false;
			$response['error'] = "No found";
		}else{
			$response['flag'] = true;
			$response['system'] = $system;
		}
		return response()->json($response);
	}
	public function getAsset($id)
	{
		$response = array();
		$asset = \App\Asset::where('id',$id)->first();
		if(is_null($asset)){
			$response['flag'] = false;
			$response['error'] = "No found";
		}else{
			$response['flag'] = true;
			$response['asset'] = $asset;
		}
		return response()->json($response);
	}
	public function getUser($id)
	{
		$response = array();
		$user = \App\User::where('id',$id)->with('cb_profile')->first();
		if(is_null($user)){
			$response['flag'] = false;
			$response['error'] = "No found";
		}else{
			$response['flag'] = true;
			$response['user'] = $user;
		}
		return response()->json($response);
	}
	function getNewSystemId(){
		$response = array();
		$system = \App\System::select('*')->orderBy('id','DESC')->first();
		if(is_null($system)){
			$response['flag'] = false;
			$response['error'] = "No Asset found";
		}else{
			$response['flag'] = true;
			$response['system'] = $system;
		}
		return response()->json($response);
	}
	public function getMasterSystemById($id){
		$response = array();
		$master_system = \App\MasterAsset::where('id',$id)->first();
		if(is_null($master_system)){
			$response['flag'] = false;
			$response['error'] = "No Asset found";
		}else{
			$response['flag'] = true;
			$response['master_system'] = $master_system;
		}
		return response()->json($response);
	}
	public function creditLeave(){
		$currentDay = date('d');
		if($currentDay != 1){
			$users = \App\EmployeeCbProfile::all();
			foreach ($users as $user) {
				if($user->leaves_taken == 0){
					$user->avail_leaves = $user->avail_leaves + 1;
				}else{
					$user->leaves_taken =  ($user->leaves_taken - 1);
				}
				$user->save();
			}
		}
	} 
	public function getEod($id)
	{
		$response = array();
		$main_eod = \App\MainEod::where('id',$id)->with('sub_eods')->first();
		if(is_null($main_eod)){
			$response['flag'] = false;
			$response['error'] = "No found";
		}else{
			$response['flag'] = true;
			$response['main_eod'] = $main_eod;
		}
		return response()->json($response);
	}
	public function getSubEod($id)
	{
		$response = array();
		$sub_eod = \App\SubEod::where('id',$id)->first();
		if(is_null($sub_eod)){
			$response['flag'] = false;
			$response['error'] = "No EOD found";
		}else{
			$response['flag'] = true;
			$response['sub_eod'] = $sub_eod;
		}
		return response()->json($response);
	}

	public function getProject($id)
	{
		$response = array();
		$project = \App\Project::where('id',$id)->first();
		if(is_null($project)){
			$response['flag'] = false;
			$response['error'] = "No Project found";
		}else{
			$response['flag'] = true;
			$response['project'] = $project;
		}
		return response()->json($response);
	}
}
