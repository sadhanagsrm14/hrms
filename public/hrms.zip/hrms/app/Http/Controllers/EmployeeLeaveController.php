<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class EmployeeLeaveController extends Controller
{
	public function myLeaves(Request $request)
	{
		if($request->type){
			if($request->type == 'approved'){
				$is_approved = 1;
			}
			elseif($request->type == 'pending'){
				$is_approved = 0;
			}
			elseif($request->type == 'rejected'){
				$is_approved = -1;
			}
			$leaves = \App\Leaves::where('user_id',\Auth::user()->id)->where('is_approved',$is_approved)->with('leave_type')->orderBy('id','DESC')->get();
		}else{
			$leaves = \App\Leaves::where('user_id',\Auth::user()->id)->with('leave_type')->orderBy('id','DESC')->get();
		}
		$data['leaves'] = $leaves;
		return view('employee.leaves.index',$data);
	} 
	public function getAddLeave()
	{
		$leave_types = \App\LeaveType::all();
		$data['leave_types'] = $leave_types;
		return view('employee.leaves.apply-leave',$data);
	} 
	public function postAddLeave(Request $request){
		$validator = \Validator::make($request->all(),
			array(
				'leave_type' =>'required',
				'date_from' =>'required',
				'date_to' =>'required',
				'contact_number' =>'required',
				'reason' =>'required',
			)
		);
		if($validator->fails())
		{
			return redirect('/employee/apply-leave')
			->withErrors($validator)
			->withInput();
		}
		else
		{
			$leave =  new \App\Leaves();
			$leave->user_id = \Auth::user()->id;
			$leave->leave_type_id = $request->leave_type;
			$leave->date_from = $request->date_from;
			$leave->date_to = $request->date_to;
			$leave->days = $request->days;
			$leave->contact_number = $request->contact_number;
			$leave->reason = $request->reason;
			$url = url('role/leave-listing?type=pending');
			if($leave->save()){ 
				/*-----------------------------------Send notification-------------------------------------------*/
				$user = \App\User::where('id',\Auth::user()->id)->first();
				$receiver = array();
				$title = $user->first_name." ".$user->last_name." "."Requested for Leave";
				$message = $user->first_name." ".$user->last_name." "."Requested for Leave."."<br>";
				$message.= "<a href='".$url."' class='btn btn-primary'>view</a>";
				$admins = \App\User::where('role','1')->get();
				foreach ($admins as $admin) {
					array_push($receiver,$admin->id);
				}
				$hrs = \App\User::where('role','2')->get();
				foreach ($hrs as $hr) {
					array_push($receiver,$hr->id);
				}
				NotificationController::notify(\Auth::user()->id,$receiver,$title,$message);
				/*-----------------------------------Send notification-------------------------------------------*/
				return redirect('/employee/my-leaves')->with('success',"Added Successfully.");
			}else{
				return redirect('/employee/my-leaves')->with('error',"Something Went Wrong.");
			}
		}

	}
}
