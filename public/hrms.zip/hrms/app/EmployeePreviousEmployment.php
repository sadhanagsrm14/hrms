<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EmployeePreviousEmployment extends Model
{
    //
}
