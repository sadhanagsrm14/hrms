<?php 

function getAttendanceBydate($mydate,$employee_id){
    $attendance = \App\AttendanceData::where('attendance_date',$mydate)->where('employee_id',$employee_id)->first(); 
    if(count($attendance) == 1){
        return $attendance->status;   
    }else{
        return false;   
    }   
    
    
}

function isAttendanceDone($mydate,$employee_id){
    $attendance = \App\AttendanceData::where('attendance_date',$mydate)->where('employee_id',$employee_id)->first(); 
    if(count($attendance) == 1){
        return true;   
    }else{
        return false;   
    }   
    
    
}


function getRoleById($role_id){
    $role = \App\Role::find($role_id);
    $role_name = $role->role;
    return $role_name;
}
function getUserById($user_id){
    $user = \App\User::find($user_id);
    return $user;
}
function getSystemById($system_id){
    $system = \App\System::find($system_id);
    return $system;
}
function getAssetById($asset_id){
    $asset = \App\Asset::find($asset_id);
    return $asset;
}
function getProjectById($user_id){
    $project = \App\Project::find($user_id);
    return $project;
}
function getProject($id){
    $project = \App\Project::find($id);
    // if(is_null($project)){
    //     $project = new \stdClass();
    //     $project->name = "N/A";
    // }
    return $project;
}
function getUnreadNotificationsById($receiver_id){
    $notifications = \App\Notification::where('receiver_id',$receiver_id)->where('is_read',0)->orderBy('id','DESC')->get();
    return count($notifications);
}
function getNotificationsById($receiver_id){
    $notifications = \App\Notification::where('receiver_id',$receiver_id)->where('is_read',0)->orderBy('id','DESC')->get();
    return $notifications;
}
function calculateTimeSpan($date){
    $seconds  = strtotime(date('Y-m-d H:i:s')) - strtotime($date);

    $months = floor($seconds / (3600*24*30));
    $day = floor($seconds / (3600*24));
    $hours = floor($seconds / 3600);
    $mins = floor(($seconds - ($hours*3600)) / 60);
    $secs = floor($seconds % 60);

    if($seconds < 60){
        $time = $secs." sec ago";
    }
    else if($seconds < 60*60 ){
        $time = $mins." min ago";
    }
    else if($seconds < 24*60*60){
        $time = $hours." hrs ago";
    }
    else if($seconds < 24*60*60*30){
        $time = $day." day ago";
    }
    else{
        $time = $months." month ago";
    }
    return $time;
}
function isHoliday($date,$category){
    $holiday = \App\Holiday::where('date',$date)->where('category',$category)->first();
    if(is_null($holiday)){
        return false;
    }else{
        return true;
    }
}
function holidayComment($date,$category){
    $holiday = \App\Holiday::where('date',$date)->where('category',$category)->first();
    if(is_null($holiday)){
        return false;
    }else{
        return $holiday;
    }
}
function getLeaves($user_id,$is_approved){
    $leaves = \App\Leaves::where('user_id',\Auth::user()->id)->where('is_approved',$is_approved)->get();
    return $leaves;
} 
function setActive($path)
{
    return Request::is($path) ? 'open' : '1';
}
?>