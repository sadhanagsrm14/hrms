<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class System extends Model
{
	public function assets(){
		return $this->hasMany('\App\SystemAsset');
	}
}
